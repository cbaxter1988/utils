from dataclasses import dataclass


@dataclass(frozen=True)
class ValueObject:
    """
    This Class is meant to inheritied
    """


