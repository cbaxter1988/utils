from setuptools import setup, find_packages

setup(
    name='cbaxter1988_utils',
    version='0.0.1',
    url='http://www.github.com/cbaxter1988',
    description='A Package containing my utils',
    author='Courtney S Baxter Jr',
    author_email='cbaxtertech@gmail.com',
    packages=find_packages(),
    include_package_data=True
)
